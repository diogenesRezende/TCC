package br.edu.univas.restapiapp.model;

public enum TipoEvento {
	PROVA_AGENDADA, PROVA_APLICADA, FALTAS
}
