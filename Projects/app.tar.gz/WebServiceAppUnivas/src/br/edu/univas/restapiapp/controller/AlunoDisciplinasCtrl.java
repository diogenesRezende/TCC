package br.edu.univas.restapiapp.controller;

import java.util.List;

import javax.persistence.EntityManager;

import br.edu.univas.restapiapp.model.Aluno;
import br.edu.univas.restapiapp.util.JpaUtil;

public class AlunoDisciplinasCtrl {

	public List<Aluno> getDisciplinasByMatricula(Long idAluno) {
		EntityManager em = JpaUtil.getEntityManager();
		List<Aluno> alunos = em
				.createQuery(
						"select distinct a from Aluno a inner join fetch a.periodo inner join fetch",
						Aluno.class).getResultList();
		return alunos;
	}
}
