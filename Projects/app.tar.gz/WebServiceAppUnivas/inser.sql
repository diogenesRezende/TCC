INSERT INTO alunos(
            id_aluno, email, id_externo, nome, periodo)
    VALUES (1, 'diogenes.rezende@gmail.com', 98004095,'Diogenes Aparecido Rezende', 8);
    COMMIT ;
INSERT INTO alunos(
            id_aluno, email, id_externo, nome, periodo)
    VALUES (2, 'NILO@gmail.com', 98004096,'Nilo', 8);
    COMMIT ;
    INSERT INTO alunos(
            id_aluno, email, id_externo, nome, periodo)
    VALUES (3, 'diego@gmail.com', 98004097,'Diego', 8);
    COMMIT ;
    INSERT INTO alunos(
            id_aluno, email, id_externo, nome, periodo)
    VALUES (4, 'otavio@gmail.com', 98004098,'Otavio', 8);
    COMMIT ;
    
    
    INSERT INTO disciplinas(
            id_disciplina, descricao, id_externo, nome)
    VALUES (1, 'Engenharia de Software', 1032, 'Engenharia de Software');
    commit;

    INSERT INTO disciplinas(
            id_disciplina, descricao, id_externo, nome)
    VALUES (2, 'Qualidade de Software', 1033, 'Qualidade de Software');
    commit;

INSERT INTO disciplinas(
            id_disciplina, descricao, id_externo, nome)
    VALUES (3, 'Lab. Prog. III', 1034, 'Lab. Prog. III');
    commit;
    
    INSERT INTO eventos(
            id_evento, data_efetiva, data_lancamento, nota, tipo_evento, 
            id_discplina, id_aluno)
    VALUES (1, now(), now(), 30.0, 'PROVA_AGENDADA', 
            1, 1);
            commit;

            INSERT INTO eventos(
            id_evento, data_efetiva, data_lancamento, nota, tipo_evento, 
            id_discplina, id_aluno)
    VALUES (2, now(), now(), 30.0, 'PROVA_APLICADA', 
            2, 2);
            commit;

INSERT INTO eventos(
            id_evento, data_efetiva, data_lancamento, nota, tipo_evento, 
            id_discplina, id_aluno)
    VALUES (3, now(), now(), 0.0, 'FALTA', 
            3, 3);
            commit;