package br.edu.univas.restapiapp.controller;

import java.util.List;

import javax.persistence.EntityManager;

import br.edu.univas.restapiapp.model.Evento;
import br.edu.univas.restapiapp.util.JpaUtil;

public class EventoCtrl {

	public List<Evento> getAll() {
		EntityManager em = JpaUtil.getEntityManager();
		List<Evento> eventos = em.createQuery("from Evento", Evento.class)
				.getResultList();
		return eventos;
	}
}
// public List<Aluno> getAll() {
// EntityManager em = JpaUtil.getEntityManager();
// List<Aluno> alunos = em.createQuery("from Aluno", Aluno.class)
// .getResultList();
// return alunos;
// }